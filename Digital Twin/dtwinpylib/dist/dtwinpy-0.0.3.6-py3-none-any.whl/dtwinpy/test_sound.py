from .helper import Helper

helper = Helper()
helper.printer("test")