# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 22:59:24 2020

@author: giova
"""

# just init 