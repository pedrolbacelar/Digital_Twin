from manpy.simulation.applications.MilkPlant.MilkTank import MilkTank
from manpy.simulation.applications.MilkPlant.MilkTransport import MilkTransport
from manpy.simulation.applications.MilkPlant.MilkPack import MilkPack
from manpy.simulation.applications.MilkPlant.MilkProcess import MilkProcess
from manpy.simulation.applications.MilkPlant.MilkExit import MilkExit
