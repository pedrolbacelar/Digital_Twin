from setuptools import find_packages, setup
setup(
    name='dtpy',
    packages=find_packages(include=['dtpy']),
    version='0.0.1',
    description='Digital Twin Library',
    author='Pedro Bacelar and Alex',
    license='MIT'
)