from distutils.core import setup

setup(
    name='dtpy',
    version='0.0.2',
    py_modules=[],
    )
