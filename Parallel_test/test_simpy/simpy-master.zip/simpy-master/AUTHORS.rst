Authors
=======

SimPy was originally created by Klaus G. Müller and Tony Vignaux in 2002.

In 2008, Ontje Lünsdorf and Stefan Scherfke started to contribute to SimPy and
became active maintainers in 2011.

In 2011, Karen Turner came on board to generally help with all the bits and
pieces that may get forgotten :-)

We’d also like to thank:

- Johannes Koomer
- Steven Kennedy
- Matthew Grogan
- Sean Reed
- Christoph Körner
- Andreas Beham
- Larissa Reis
- Peter Grayson
- Cristian Klein
