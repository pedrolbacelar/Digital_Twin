=======
License
=======

.. include:: ../../LICENSE.rst
