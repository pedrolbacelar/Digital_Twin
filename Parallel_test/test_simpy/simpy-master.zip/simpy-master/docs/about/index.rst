.. _about:

===========
About SimPy
===========

This sections is all about the non-technical stuff. How did SimPy evolve? Who
was responsible for it? And what the heck were they thinking when they made it?


.. toctree::
   :maxdepth: 1

   history
   acknowledgements
   ports
   defense_of_design
   release_process
   license
