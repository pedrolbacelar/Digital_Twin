======================================================
``simpy.exceptions`` --- Exception types used by SimPy
======================================================

.. automodule:: simpy.exceptions
   :members:
